#ifndef HEADER_H
#define HEADER_H



//#pragma comment(lib, "wldap32.lib" )

//#include <curl/curl.h>
#include <obfsucate/obfuscate.h>
#include <windows.h>
#include <d3dcompiler.h>
#include <iostream>

#include <vector>
#include <string>

#include "ImGui/imgui.h"
#include "ImGui/imgui_internal.h"
#include "ImGui/imgui_toggle.h"
#include "ImGui/imgui_toggle_presets.h"

#include <d3d11.h>
#include <tchar.h>
#include <chrono>
#include <ctime>
#include <cstdint>

// My Headers
#include "Font.h"
#include "Icon.h"
#include "Iconapp.h"
#include "Drawing.h"
#include "EFunctions.h"
#include "UI.h"
#endif








