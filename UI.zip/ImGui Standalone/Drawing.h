#ifndef DRAWING_H
#define DRAWING_H
#include "Headers.h"


class EFunctions;

class MainMenu
{
public:
    MainMenu() = delete;
    MainMenu(MainMenu&) = delete;
    MainMenu& operator=(MainMenu&) = delete;
    MainMenu(const char* icon,  const char* name,  const char* subName);
    void CreateChild(const char* name, const ImVec2& size);

    static void Render();

    std::string m_name;
    std::string m_icon;
    std::string m_subName;
    int m_id;

    class Child
    {
    public:
        Child() = delete;
        Child(Child&) = delete;
        Child& operator=(Child&) = delete;
        Child(MainMenu* Parent, const char* name, const ImVec2& size);
        ~Child();
        MainMenu* _Parent;
        ImVec2 mc_Size;
        std::string mc_Name;
        
        int mc_Id;

        ImVec2 mc_CursorPos;
        EFunctions* mc_EFunction{ nullptr };
    };

    
    int m_MaxChildId{ 0 };
    static std::vector<MainMenu*> s_MainMenu;
    static int s_MaxTab;
    static int s_RunningTab;
    std::vector<Child*> m_Childs;
public:
    Child* m_ScopedChild;
};


class Drawing
{
private:
	static LPCSTR lpWindowName;
	static ImVec2 vWindowSize;
	static ImGuiWindowFlags WindowFlags;
	static bool bDraw;

public:
	static void Active();
	static bool isActive();
	static void Draw();
	static void Theme();
};

#endif
