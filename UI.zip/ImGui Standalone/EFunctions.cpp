#include "EFunctions.h"


extern bool CreateButton(const char* name, ImVec2 size, bool centered = true, bool textCentered = true, bool shadow = false, ImGuiCol_ backGround = ImGuiCol_WindowBg);
extern void DrawHorizontalLine(const ImVec2& start, const ImVec2& end, ImU32 color, float thickness);
extern void DrawHorizontalRect(const ImVec2& start, const ImVec2& end, ImU32 color);

extern ImVec4 inc_ImVec4(const ImVec4& vec, float inc);
extern void SpaceY(int space);
extern void SpaceX(int space);


extern ImDrawList* g_pDrawList;


Aimbot* g_pAimbot	= new Aimbot();
Esp* g_pEsp			= new Esp();
Chat* g_pChat		= new Chat();


void Aimbot::Run()
{
	
	


}


void Esp::Element::Render(const char* name, int xSpaceing)
{
	ImGui::PushStyleColor(ImGuiCol_ButtonActive, GetColor());
	ImGui::PushStyleColor(ImGuiCol_Button, GetColor());
	ImGui::PushStyleColor(ImGuiCol_ButtonHovered, GetColor());

	ImGui::SameLine();
	SpaceX(xSpaceing);
	if (ImGui::Button(name, ImVec2(20, 20)))
	{
		ImGui::OpenPopup(name);
	}
	if (ImGui::BeginPopup(name))
	{
		ImGui::ColorPicker4(name, _color, ImGuiColorEditFlags_AlphaPreviewHalf | ImGuiColorEditFlags_NoOptions | ImGuiColorEditFlags_PickerHueWheel);
		ImGui::EndPopup();
	}
	ImGui::PopStyleColor(3);
}

void Esp::Init()
{
	_isEnabled = true;
	_elementPlayerBox._isEnabled = true;
	_elementPlayerBox.SetColor(0.0, 1.0, 1.0);
	_elementShowName.SetColor(1.0, 0.0, 1.0);
	_elementShowName._isEnabled = true;
	_elementHealth.SetColor(0.0, 1.0, 0.0);
	_elementHealth._isEnabled = true;
	_elementWeapon.SetColor(0.0, 0.93, 0.09);
	_elementWeapon._isEnabled = true;
	_elementSkeleton.SetColor(1.00, 0.00, 0.00);
	_elementSkeleton._isEnabled = true;
	
}

void Esp::ShowEspWindow()
{
	if (!_isEnabled) return;
	ImVec2 WindowPos = ImGui::GetWindowPos();
	ImGui::SetNextWindowPos(ImVec2(WindowPos.x + 410, WindowPos.y + 11));
	ImGui::Begin("Esp Preview", 0, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar);
	
	ImGui::BeginChild("Esp Preview", ImVec2(230, 400), ImGuiWindowFlags_NoBackground);
	ImGui::SetCursorPosX((230 - ImGui::CalcTextSize("Esp Preview").x) / 2.);
	SpaceY(5);
	ImGui::Text("Esp Preview");

	SpaceY(30);

	// 40 * 60    // 190 * 350
	if (_elementShowName._isEnabled)
	{
		ImGui::SetCursorPosX((230 - ImGui::CalcTextSize("sicklyl (228 m)").x) / 2.);
		ImGui::TextColored(_elementShowName.GetColor(), "%s", "sicklyl (228 m)");
	}
	ImVec2 BoxCursorPos;
	ImVec2 BoxSize{ 150 , 290};
	if (_elementPlayerBox._isEnabled)
	{
		if (_boxType != 1)
		{
			ImGui::SetCursorPosX(40);
			ImGui::SetCursorPosY(65);
			ImDrawList* draw_list = ImGui::GetWindowDrawList();

			ImVec2 CursorScreenPos = ImGui::GetCursorScreenPos();
			BoxCursorPos = ImGui::GetCursorPos();
			draw_list->AddRect(CursorScreenPos, ImVec2(CursorScreenPos.x + BoxSize.x, CursorScreenPos.y + BoxSize.y), ImColor(_elementPlayerBox.GetColor()));

		}
		else
		{
			ImGui::SetCursorPosX(40);
			ImGui::SetCursorPosY(65);
			ImDrawList* draw_list = ImGui::GetWindowDrawList();
			ImVec2 CursorScreenPos = ImGui::GetCursorScreenPos();
			BoxCursorPos = ImGui::GetCursorPos();

			ImVec2 TopLeftPoint		= CursorScreenPos;
			ImVec2 TopRightPoint	= TopLeftPoint;		TopRightPoint.x		+= BoxSize.x;
			ImVec2 LowerLeftPoint	= TopLeftPoint;		TopLeftPoint.y		+= BoxSize.y;
			ImVec2 LowerRightPoint	= TopRightPoint;	LowerRightPoint.y	+= BoxSize.y;

			draw_list->AddLine(TopLeftPoint, ImVec2(TopLeftPoint.x + 50, TopLeftPoint.y), ImColor(_elementPlayerBox.GetColor()));
			draw_list->AddLine(TopLeftPoint, ImVec2(TopLeftPoint.x, TopLeftPoint.y - 50), ImColor(_elementPlayerBox.GetColor()));

			draw_list->AddLine(TopRightPoint, ImVec2(TopRightPoint.x - 50, TopRightPoint.y), ImColor(_elementPlayerBox.GetColor()));
			draw_list->AddLine(TopRightPoint, ImVec2(TopRightPoint.x, TopRightPoint.y + 50), ImColor(_elementPlayerBox.GetColor()));

			draw_list->AddLine(LowerLeftPoint, ImVec2(LowerLeftPoint.x + 50, LowerLeftPoint.y), ImColor(_elementPlayerBox.GetColor()));
			draw_list->AddLine(LowerLeftPoint, ImVec2(LowerLeftPoint.x , LowerLeftPoint.y + 50), ImColor(_elementPlayerBox.GetColor()));

			draw_list->AddLine(LowerRightPoint, ImVec2(LowerRightPoint.x - 50, LowerRightPoint.y), ImColor(_elementPlayerBox.GetColor()));
			draw_list->AddLine(LowerRightPoint, ImVec2(LowerRightPoint.x, LowerRightPoint.y  - 50), ImColor(_elementPlayerBox.GetColor()));


		}
	}
	ImVec2 BoxMiddleCursorPos{ BoxCursorPos.x + BoxSize.x / 2.f , BoxCursorPos.y + BoxSize.y / 2.f };

	if (_elementHealth._isEnabled)
	{
		ImGui::SetCursorPosX(33);
		ImGui::SetCursorPosY(65);
		ImDrawList* draw_list = ImGui::GetWindowDrawList();

		ImVec2 CursorScreenPos = ImGui::GetCursorScreenPos();
		draw_list->AddRectFilled(CursorScreenPos, ImVec2(CursorScreenPos.x + 3, CursorScreenPos.y + 290), ImColor(_elementHealth.GetColor()));
	}

	if (_elementWeapon._isEnabled)
	{
		ImGui::SetCursorPosY(360);
		ImGui::SetCursorPosX((230 - ImGui::CalcTextSize("Assault Rifle").x) / 2.);
		ImGui::TextColored(_elementWeapon.GetColor(), "%s", "Assault Rifle");
	}
	if (_elementSkeleton._isEnabled)
	{
		ImDrawList* draw_list = ImGui::GetWindowDrawList();

		ImVec2 headPos(BoxMiddleCursorPos.x, 95);
		ImVec2 NeckPos(BoxMiddleCursorPos.x, 125);

		ImVec2 LeftKo3Pos(BoxMiddleCursorPos.x - 15, 130);
		ImVec2 RigthKo3Pos(BoxMiddleCursorPos.x + 15, 130);

		ImVec2 LeftElbowPos(BoxMiddleCursorPos.x  - 40, 160);
		ImVec2 RightElbowPos(BoxMiddleCursorPos.x + 40, 160);

		ImVec2 LeftHandPos(BoxMiddleCursorPos.x - 60, 190);
		ImVec2 RightHandPos(BoxMiddleCursorPos.x + 60, 190);

		ImVec2 a__Pos(BoxMiddleCursorPos.x, 200);
		

		ImVec2 LeftLegPos(BoxMiddleCursorPos.x - 15, 275);
		ImVec2 RightLegPos(BoxMiddleCursorPos.x + 15, 275);

		ImVec2 LeftFootPos(BoxMiddleCursorPos.x - 20, 345);
		ImVec2 RightFootPos(BoxMiddleCursorPos.x + 20, 345);

		ImGui::SetCursorPos(headPos);
		draw_list->AddCircle(ImGui::GetCursorScreenPos(), 20, ImColor(_elementSkeleton.GetColor()));

		ImGui::SetCursorPos(NeckPos);
		ImVec2 CursorScreenPos = ImGui::GetCursorScreenPos();
		draw_list->AddLine(CursorScreenPos, ImVec2(CursorScreenPos.x, CursorScreenPos.y - 10), ImColor(_elementSkeleton.GetColor()));

		ImGui::SetCursorPos(NeckPos);
		CursorScreenPos = ImGui::GetCursorScreenPos();
		ImGui::SetCursorPos(LeftKo3Pos);
		ImVec2 CursorScreenPos2 = ImGui::GetCursorScreenPos();
		draw_list->AddLine(CursorScreenPos, CursorScreenPos2, ImColor(_elementSkeleton.GetColor()));

		ImGui::SetCursorPos(RigthKo3Pos);
		CursorScreenPos2 = ImGui::GetCursorScreenPos();
		draw_list->AddLine(CursorScreenPos, CursorScreenPos2, ImColor(_elementSkeleton.GetColor()));

		ImGui::SetCursorPos(LeftKo3Pos);
		CursorScreenPos = ImGui::GetCursorScreenPos();
		ImGui::SetCursorPos(LeftElbowPos);
		CursorScreenPos2 = ImGui::GetCursorScreenPos();
		draw_list->AddLine(CursorScreenPos, CursorScreenPos2, ImColor(_elementSkeleton.GetColor()));
		
		ImGui::SetCursorPos(RigthKo3Pos);
		CursorScreenPos = ImGui::GetCursorScreenPos();
		ImGui::SetCursorPos(RightElbowPos);
		CursorScreenPos2 = ImGui::GetCursorScreenPos();
		draw_list->AddLine(CursorScreenPos, CursorScreenPos2, ImColor(_elementSkeleton.GetColor()));


		ImGui::SetCursorPos(LeftElbowPos);
		CursorScreenPos = ImGui::GetCursorScreenPos();
		ImGui::SetCursorPos(LeftHandPos);
		CursorScreenPos2 = ImGui::GetCursorScreenPos();
		draw_list->AddLine(CursorScreenPos, CursorScreenPos2, ImColor(_elementSkeleton.GetColor()));

		ImGui::SetCursorPos(RightElbowPos);
		CursorScreenPos = ImGui::GetCursorScreenPos();
		ImGui::SetCursorPos(RightHandPos);
		CursorScreenPos2 = ImGui::GetCursorScreenPos();
		draw_list->AddLine(CursorScreenPos, CursorScreenPos2, ImColor(_elementSkeleton.GetColor()));


		ImGui::SetCursorPos(NeckPos);
		CursorScreenPos = ImGui::GetCursorScreenPos();
		ImGui::SetCursorPos(a__Pos);
		CursorScreenPos2 = ImGui::GetCursorScreenPos();
		draw_list->AddLine(CursorScreenPos, CursorScreenPos2, ImColor(_elementSkeleton.GetColor()));


		ImGui::SetCursorPos(LeftLegPos);
		CursorScreenPos = ImGui::GetCursorScreenPos();
		ImGui::SetCursorPos(a__Pos);
		CursorScreenPos2 = ImGui::GetCursorScreenPos();
		draw_list->AddLine(CursorScreenPos, CursorScreenPos2, ImColor(_elementSkeleton.GetColor()));

		ImGui::SetCursorPos(RightLegPos);
		CursorScreenPos = ImGui::GetCursorScreenPos();
		ImGui::SetCursorPos(a__Pos);
		CursorScreenPos2 = ImGui::GetCursorScreenPos();
		draw_list->AddLine(CursorScreenPos, CursorScreenPos2, ImColor(_elementSkeleton.GetColor()));


		ImGui::SetCursorPos(LeftLegPos);
		CursorScreenPos = ImGui::GetCursorScreenPos();
		ImGui::SetCursorPos(LeftFootPos);
		CursorScreenPos2 = ImGui::GetCursorScreenPos();
		draw_list->AddLine(CursorScreenPos, CursorScreenPos2, ImColor(_elementSkeleton.GetColor()));

		ImGui::SetCursorPos(RightLegPos);
		CursorScreenPos = ImGui::GetCursorScreenPos();
		ImGui::SetCursorPos(RightFootPos);
		CursorScreenPos2 = ImGui::GetCursorScreenPos();
		draw_list->AddLine(CursorScreenPos, CursorScreenPos2, ImColor(_elementSkeleton.GetColor()));
	}
	ImGui::EndChild();


	ImGui::End();
}

void Esp::Run()
{
	static bool init = false;

	if (!init)
	{
		Init();
		init = true;
	}

	SpaceY(20);
	SpaceX(10);

	ImVec4 hideColor = ImVec4(0.26, 0.27, 0.30, 1.0f);
	ImVec4 activeColor = ImVec4(1.f, 1.f, 1.f, 1.0f);
	{
		ImVec2 MousePos = ImGui::GetCursorPos();
		if (ImGui::Button("##Player", ImGui::CalcTextSize("Player")))
		{
			_tab = 0;
		}
		ImGui::SetCursorPos(MousePos);
		ImGui::TextColored(_tab == 0 ? activeColor : hideColor, "%s", "Player");


		if (_tab == 0)
		{
			ImVec2 MouseScreenPos = ImGui::GetCursorScreenPos();
			MouseScreenPos.x += MousePos.x;
			MouseScreenPos.y += 2;
			DrawHorizontalLine(MouseScreenPos, ImVec2(MouseScreenPos.x + ImGui::CalcTextSize("Player").x, MouseScreenPos.y),ImColor(90, 181, 218),2);
		}


		ImGui::SameLine();
		SpaceX(20);
		MousePos = ImGui::GetCursorPos();
		if (ImGui::Button("##World", ImGui::CalcTextSize("World")))
		{
			_tab = 1;
		}
		ImGui::SetCursorPos(MousePos);
		ImGui::TextColored(_tab == 1 ? activeColor : hideColor, "%s", "World");

		if (_tab == 1)
		{
			ImVec2 MouseScreenPos = ImGui::GetCursorScreenPos();
			MouseScreenPos.x += MousePos.x;
			MouseScreenPos.y += 2;
			DrawHorizontalLine(MouseScreenPos, ImVec2(MouseScreenPos.x + ImGui::CalcTextSize("World").x, MouseScreenPos.y), ImColor(90, 181, 218), 2);
		}
		
	}
	
	ShowEspWindow();
	SpaceY(25);
	SpaceX(25);


		ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 1.0f); // Set the frame border size
		ImGui::PushStyleColor(ImGuiCol_Border, ImVec4(0.2, 0.22, 0.24,1.f)); // Set border color


		
		ImGui::PushStyleColor(ImGuiCol_CheckMark, ImVec4(1., 1., 1.,1.));

		ImGui::PushStyleColor(ImGuiCol_FrameBg, _isEnabled ? ImVec4(0.35, 0.71, 0.85, 1.) : ImGui::GetStyleColorVec4(ImGuiCol_FrameBg));
		ImGui::Checkbox("Enable Player Esp", &_isEnabled);
		ImGui::PopStyleColor();
		SpaceY(10);
		SpaceX(25);
		ImGui::Text("Player box");
		_elementPlayerBox.Render("##Player box",240);

		static bool Choosing = false;
		const char* items[] = { "Normal Box", "Corner Box", "3D Box" };
		//SpaceY(5);
		SpaceX(25);
		ImGui::BeginChild("Style Box", ImVec2(250, 25),true);

		SpaceY(5);
		SpaceX(5);
		ImGui::Text("Choose Style Box");
		ImGui::SameLine();
		ImGui::SetCursorPosX(250 - 25);
		ImGui::SetCursorPosY(0);
		ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f); // Set the frame border size
		if (ImGui::Button(Choosing ? ICON_FA_ARROW_UP : ICON_FA_ARROW_DOWN, ImVec2(25, 25)))
		{
			Choosing = Choosing ? false : true;
		}
		ImGui::PopStyleVar();
		ImGui::EndChild();
		if (Choosing)
		{
			SpaceX(25);
			ImGui::SetNextItemWidth(250);
			if (ImGui::ListBox("##List", &_boxType, items, 3))
			{
				Choosing = false;
			}
			
		}
		

		SpaceY(5);
		SpaceX(25);
		ImGui::PushStyleColor(ImGuiCol_FrameBg, _elementFillBox._isEnabled ? ImVec4(0.35, 0.71, 0.85, 1.) : ImGui::GetStyleColorVec4(ImGuiCol_FrameBg));
		ImGui::Checkbox("FillBox", &_elementFillBox._isEnabled);
		ImGui::PopStyleColor();
		SpaceY(5);
		SpaceX(25);
		ImGui::PushStyleColor(ImGuiCol_FrameBg, _elementChamsSkin._isEnabled ? ImVec4(0.35, 0.71, 0.85, 1.) : ImGui::GetStyleColorVec4(ImGuiCol_FrameBg));

		ImGui::Checkbox("CharmsSkin", &_elementChamsSkin._isEnabled);
		ImGui::PopStyleColor();
		SpaceY(5);
		SpaceX(25);
		ImGui::PushStyleColor(ImGuiCol_FrameBg, _elementShowName._isEnabled ? ImVec4(0.35, 0.71, 0.85, 1.) : ImGui::GetStyleColorVec4(ImGuiCol_FrameBg));

		ImGui::Checkbox("Show Name", &_elementShowName._isEnabled);
		ImGui::PopStyleColor();
		_elementShowName.Render("##Show Name",20);



		SpaceY(5);
		SpaceX(25);
		ImGui::PushStyleColor(ImGuiCol_FrameBg, _elementHealth._isEnabled ? ImVec4(0.35, 0.71, 0.85, 1.) : ImGui::GetStyleColorVec4(ImGuiCol_FrameBg));

		ImGui::Checkbox("Health", &_elementHealth._isEnabled);
		ImGui::PopStyleColor();
		SpaceY(5);
		SpaceX(25);
		ImGui::PushStyleColor(ImGuiCol_FrameBg, _elementWeapon._isEnabled ? ImVec4(0.35, 0.71, 0.85, 1.) : ImGui::GetStyleColorVec4(ImGuiCol_FrameBg));

		ImGui::Checkbox("Weapon", &_elementWeapon._isEnabled);
		ImGui::PopStyleColor();
		_elementWeapon.Render("##Weapon", 20);
		
		SpaceY(5);
		SpaceX(25);
		ImGui::PushStyleColor(ImGuiCol_FrameBg, _elementDistance._isEnabled ? ImVec4(0.35, 0.71, 0.85, 1.) : ImGui::GetStyleColorVec4(ImGuiCol_FrameBg));

		ImGui::Checkbox("Distance", &_elementDistance._isEnabled);
		ImGui::PopStyleColor();
		SpaceY(5);
		SpaceX(25);
		ImGui::PushStyleColor(ImGuiCol_FrameBg, _elementIgnoreSleepers._isEnabled ? ImVec4(0.35, 0.71, 0.85, 1.) : ImGui::GetStyleColorVec4(ImGuiCol_FrameBg));

		ImGui::Checkbox("Ignore sleepers", &_elementIgnoreSleepers._isEnabled);
		ImGui::PopStyleColor();
		SpaceY(5);
		SpaceX(25);
		ImGui::PushStyleColor(ImGuiCol_FrameBg, _elementSkeleton._isEnabled ? ImVec4(0.35, 0.71, 0.85, 1.) : ImGui::GetStyleColorVec4(ImGuiCol_FrameBg));

		ImGui::Checkbox("Skeleton", &_elementSkeleton._isEnabled);
		ImGui::PopStyleColor();
		_elementSkeleton.Render("##Skeleton", 20);

		SpaceY(5);
		SpaceX(25);

		ImGui::Text("Bot");
		SpaceY(5);
		SpaceX(25);
		ImGui::PushStyleColor(ImGuiCol_FrameBg, _elementBotsBoxes._isEnabled ? ImVec4(0.35, 0.71, 0.85, 1.) : ImGui::GetStyleColorVec4(ImGuiCol_FrameBg));

		ImGui::Checkbox("BotsBoxes", &_elementBotsBoxes._isEnabled);
		ImGui::PopStyleColor();
		SpaceY(5);
		SpaceX(25);
		ImGui::PushStyleColor(ImGuiCol_FrameBg, _elementBotsSkeleton._isEnabled ? ImVec4(0.35, 0.71, 0.85, 1.) : ImGui::GetStyleColorVec4(ImGuiCol_FrameBg));

		ImGui::Checkbox("enable bots skeleton", &_elementBotsSkeleton._isEnabled);
		ImGui::PopStyleColor();
		SpaceY(5);
		SpaceX(25);


		ImGui::PopStyleColor(2);
		ImGui::PopStyleVar();
	

}






void Chat::Run()
{
	
	
}
