#include "Drawing.h"



extern ImFont* ExtraLargeFont;
extern ImFont* LargeFont;
extern ImFont* SmallFont;

LPCSTR Drawing::lpWindowName = AY_OBFUSCATE("GamingAET");
ImVec2 Drawing::vWindowSize = { 600, 200 };

int MainMenu::s_MaxTab{ 0 };
int MainMenu::s_RunningTab{ 0 };

std::vector<MainMenu*> MainMenu::s_MainMenu;

//constexpr int  Element_ComboBox::m_MaxSizeY;



void DrawHorizontalLine(const ImVec2& start, const ImVec2& end, ImU32 color, float thickness)
{
	ImDrawList* draw_list = ImGui::GetWindowDrawList();
	draw_list->AddLine(start, end, color, thickness);
}
void DrawHorizontalRect(const ImVec2& start, const ImVec2& end, ImU32 color)
{

	ImDrawList* draw_list = ImGui::GetWindowDrawList();
	draw_list->AddRectFilledMultiColor(start, end, color, ImColor(0, 0, 0, 0), color, ImColor(0, 0, 0, 0));
}

bool CreateButton(const char* name, ImVec2 size, bool centered = true, bool textCentered = true, bool shadow = false, ImGuiCol_ backGround = ImGuiCol_WindowBg)
{
	
	if (centered)
		ImGui::SetCursorPosX(ImGui::GetContentRegionAvail().x / 2.f - size.x / 2.f);

	ImVec2 CursorPos = ImGui::GetCursorPos();

	if (!textCentered)
		ImGui::PushStyleVar(ImGuiStyleVar_ButtonTextAlign, ImVec2(0.1, 0.5));
	bool state = ImGui::Button(name, size);

	if (!textCentered)
		ImGui::PopStyleVar();


	if (shadow)
	{
		ImDrawList* draw_list = ImGui::GetWindowDrawList();
		ImVec2 window_pos = ImGui::GetWindowPos();
		
		ImColor TopColor = { 0,0,0,255 };
		ImVec4 DownColorVec = ImGui::GetStyleColorVec4(backGround);
		DownColorVec.w = 0;
		ImColor DownColor = DownColorVec;
		draw_list->AddRectFilledMultiColor(ImVec2(CursorPos.x + window_pos.x + 5 - ImGui::GetScrollX(), CursorPos.y + window_pos.y + size.y - ImGui::GetScrollY()),
			ImVec2(CursorPos.x + window_pos.x + size.x - 5 - ImGui::GetScrollY(), CursorPos.y + window_pos.y + size.y + 10 - ImGui::GetScrollY()),
			TopColor, TopColor,
			DownColor, DownColor
		);
	}

	return state;
}



void SpaceY(int space)
{
	ImGui::SetCursorPosY(ImGui::GetCursorPosY() + space);
}
void SpaceX(int space)
{
	ImGui::SetCursorPosX(ImGui::GetCursorPosX() + space);
}

ImVec4 to_ImVec4(float x, float y, float z)
{
	return ImVec4(x / 255, y / 255, z / 255, 1.f);
}
ImVec4 inc_ImVec4(const ImVec4& vec, float inc)
{
	return ImVec4(vec.x + inc / 255, vec.y + inc / 255, vec.z + inc / 255, vec.w + inc / 255);
}


ImGuiWindowFlags Drawing::WindowFlags = ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove |ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize| ImGuiWindowFlags_NoTitleBar;
bool Drawing::bDraw = true;

void Drawing::Active()
{
	bDraw = true;
}

bool Drawing::isActive()
{
	return bDraw == true;
}

ImDrawList* g_pDrawList;

extern HWND Hwnd;
void Drawing::Draw()
{
	
	static bool _init = true;
	static char buf[50];
	if (_init)
	{
		ImGui::SetNextWindowPos(ImVec2(100, 100));
		
		ZeroMemory(buf, sizeof(buf));
		Theme();
		_init = false;
	}
	

	
	ImGui::Begin(AY_OBFUSCATE("GamingAET MainW"), 0, ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoTitleBar);   // Pass a pointer to our bool variable (the window will have a closing button that will clear the bool when clicked)
	MainMenu::Render();
	ImGui::End();
	
			
	#ifdef _WINDLL
	if (GetAsyncKeyState(VK_INSERT) & 1)
		bDraw = !bDraw;
	#endif
}

void Drawing::Theme()
{
	ImGuiStyle& style = ImGui::GetStyle();
	style.Colors[ImGuiCol_Text] = ImVec4(1.f, 1.f, 1.f, 1.00f);
	style.Colors[ImGuiCol_TextDisabled] = ImVec4(0.35f, 0.35f, 0.35f, 1.00f);
	style.Colors[ImGuiCol_WindowBg] = ImVec4(0.11, 0.12, 0.15, 1.f);
	style.Colors[ImGuiCol_ChildBg] = ImVec4(.08, 0.09, 0.10,1.f);
	style.Colors[ImGuiCol_PopupBg] = ImVec4(0.08f, 0.08f, 0.08f, 0.94f);
	style.Colors[ImGuiCol_Border] = ImVec4(0.00f, 0.00f, 0.00f, 0.50f);
	style.Colors[ImGuiCol_BorderShadow] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
	style.Colors[ImGuiCol_FrameBg] = ImVec4(0.20, 0.20, 0.20, 0.54f);
	style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.29, 0.51, 0.60, 0.67f);
	style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.31, 0.57, 0.67, 0.67f);
	style.Colors[ImGuiCol_TitleBg] = ImVec4(0.04f, 0.04f, 0.04f, 1.00f);
	style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.48f, 0.16f, 0.16f, 1.00f);
	style.Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.48f, 0.16f, 0.16f, 1.00f);
	style.Colors[ImGuiCol_MenuBarBg] = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
	style.Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.02f, 0.02f, 0.02f, 0.53f);
	style.Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.31f, 0.31f, 0.31f, 1.00f);
	style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.41f, 0.41f, 0.41f, 1.00f);
	style.Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.51f, 0.51f, 0.51f, 1.00f);
	style.Colors[ImGuiCol_CheckMark] = ImVec4(0.35, 0.71, 0.85, 1.00f);
	style.Colors[ImGuiCol_SliderGrab] = ImVec4(1.00f, 0.19f, 0.19f, 0.40f);
	style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(0.89f, 0.00f, 0.19f, 1.00f);
	style.Colors[ImGuiCol_Button] = ImVec4(1.00f, 0.00f, 0.35f, 0.40f);
	style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.70f, 0.00f, 0.26f, 1.00f);
	style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.46f, 0.00f, 0.17f, 1.00f);
	style.Colors[ImGuiCol_Header] = ImVec4(0.33f, 0.35f, 0.36f, 0.53f);
	style.Colors[ImGuiCol_HeaderHovered] = ImVec4(0.76f, 0.28f, 0.44f, 0.67f);
	style.Colors[ImGuiCol_HeaderActive] = ImVec4(0.47f, 0.47f, 0.47f, 0.67f);
	style.Colors[ImGuiCol_Separator] = ImVec4(0.32f, 0.32f, 0.32f, 1.00f);
	style.Colors[ImGuiCol_SeparatorHovered] = ImVec4(0.32f, 0.32f, 0.32f, 1.00f);
	style.Colors[ImGuiCol_SeparatorActive] = ImVec4(0.32f, 0.32f, 0.32f, 1.00f);
	style.Colors[ImGuiCol_ResizeGrip] = ImVec4(1.00f, 1.00f, 1.00f, 0.85f);
	style.Colors[ImGuiCol_ResizeGripHovered] = ImVec4(1.00f, 1.00f, 1.00f, 0.60f);
	style.Colors[ImGuiCol_ResizeGripActive] = ImVec4(1.00f, 1.00f, 1.00f, 0.90f);
	style.Colors[ImGuiCol_Tab] = ImVec4(0.07f, 0.07f, 0.07f, 0.51f);
	style.Colors[ImGuiCol_TabHovered] = ImVec4(0.86f, 0.23f, 0.43f, 0.67f);
	style.Colors[ImGuiCol_TabActive] = ImVec4(0.19f, 0.19f, 0.19f, 0.57f);
	style.Colors[ImGuiCol_TabUnfocused] = ImVec4(0.05f, 0.05f, 0.05f, 0.90f);
	style.Colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.13f, 0.13f, 0.13f, 0.74f);
	style.Colors[ImGuiCol_DockingPreview] = ImVec4(0.47f, 0.47f, 0.47f, 0.47f);
	style.Colors[ImGuiCol_DockingEmptyBg] = ImVec4(0.20f, 0.20f, 0.20f, 1.00f);
	style.Colors[ImGuiCol_PlotLines] = ImVec4(0.61f, 0.61f, 0.61f, 1.00f);
	style.Colors[ImGuiCol_PlotLinesHovered] = ImVec4(1.00f, 0.43f, 0.35f, 1.00f);
	style.Colors[ImGuiCol_PlotHistogram] = ImVec4(0.90f, 0.70f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_PlotHistogramHovered] = ImVec4(1.00f, 0.60f, 0.00f, 1.00f);
	style.Colors[ImGuiCol_TableHeaderBg] = ImVec4(0.19f, 0.19f, 0.20f, 1.00f);
	style.Colors[ImGuiCol_TableBorderStrong] = ImVec4(0.31f, 0.31f, 0.35f, 1.00f);
	style.Colors[ImGuiCol_TableBorderLight] = ImVec4(0.23f, 0.23f, 0.25f, 1.00f);
	style.Colors[ImGuiCol_TableRowBg] = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
	style.Colors[ImGuiCol_TableRowBgAlt] = ImVec4(1.00f, 1.00f, 1.00f, 0.07f);
	style.Colors[ImGuiCol_TextSelectedBg] = ImVec4(0.26f, 0.59f, 0.98f, 0.35f);
	style.Colors[ImGuiCol_DragDropTarget] = ImVec4(1.00f, 1.00f, 0.00f, 0.90f);
	style.Colors[ImGuiCol_NavHighlight] = ImVec4(0.26f, 0.59f, 0.98f, 1.00f);
	style.Colors[ImGuiCol_NavWindowingHighlight] = ImVec4(1.00f, 1.00f, 1.00f, 0.70f);
	style.Colors[ImGuiCol_NavWindowingDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.20f);
	style.Colors[ImGuiCol_ModalWindowDimBg] = ImVec4(0.80f, 0.80f, 0.80f, 0.35f);
	style.GrabRounding = style.FrameRounding = 2.3f;
	style.WindowRounding = 10.f;
	style.ChildRounding = 0.f;
	style.ChildBorderSize = 2;
	style.WindowPadding = ImVec2(0, 0);
	style.WindowBorderSize = 0.f;
	style.FrameRounding = 4.f;
	style.FramePadding = ImVec2(4,1);
	style.ItemSpacing = ImVec2(0, 0);
	style.ItemInnerSpacing = ImVec2(12.f, 0);
	//style.ButtonTextAlign = ImVec2(0, 0.5);
	style.ScrollbarSize = 6.f;
	style.PopupRounding = 8.f;
	style.PopupBorderSize = 0.f;
	
}


MainMenu::MainMenu(const char* icon, const char* name, const char* subName)
	:m_name(name), m_icon(icon), m_subName(subName)
{
	//if (m_bStandLone)
	{
		m_id = s_MaxTab++;
		s_MainMenu.push_back(this);
	}
}

void MainMenu::Render()
{
		ImVec2 window_pos = ImGui::GetWindowPos();
		ImVec2 window_size = ImGui::GetWindowSize();



		constexpr ImVec2 LeftChildSize = ImVec2(200, 425);
		ImGui::BeginChild("Main", LeftChildSize, false);


		

		constexpr int button_size = 275;
		

		for (auto Menu : s_MainMenu)
		{
			ImGui::PushStyleColor(ImGuiCol_Text, Menu->m_id == s_RunningTab ? ImGui::GetStyleColorVec4(ImGuiCol_ButtonHovered) : inc_ImVec4(ImGui::GetStyleColorVec4(ImGuiCol_ChildBg), 100));
			ImGui::PushStyleColor(ImGuiCol_Button, s_RunningTab == Menu->m_id ? ImGui::GetStyleColorVec4(ImGuiCol_WindowBg)  : ImGui::GetStyleColorVec4(ImGuiCol_ChildBg));
			ImGui::PushStyleColor(ImGuiCol_ButtonHovered, inc_ImVec4(ImGui::GetStyleColorVec4(ImGuiCol_ChildBg), 10));
			ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImGui::GetStyleColorVec4(ImGuiCol_WindowBg));
			ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 0);
			
			std::string temp("##");
			temp.append(Menu->m_name);

			
			ImVec2 MouseCursorScreenPos = ImGui::GetCursorScreenPos();
			ImVec2 MouseCursorPos       = ImGui::GetCursorPos();
			if (CreateButton(temp.c_str(), ImVec2(LeftChildSize.x, 50), false, true))
			{
				s_RunningTab = Menu->m_id;
				//ImGui::Spacing();
			}

			ImVec2 buttonSize = ImGui::GetItemRectSize();
			ImGui::SetCursorPosY(MouseCursorPos.y + 15);
			ImGui::SetCursorPosX(15);

			ImGui::PushFont(ExtraLargeFont);
			ImGui::TextColored(ImVec4(0.39, 0.72, 0.87, 1.0f), "%s", Menu->m_icon.c_str());
			ImGui::PopFont();


			ImGui::SetCursorPosX(50);
			ImGui::SetCursorPosY(MouseCursorPos.y + 10);
			ImGui::PushFont(LargeFont);
			ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), "%s", Menu->m_name.c_str());
			ImGui::PopFont();

			ImGui::SetCursorPosX(50);
			ImGui::PushFont(SmallFont);
			ImGui::TextColored(ImVec4(0.27, 0.29, 0.31, 1.f), "%s", Menu->m_subName.c_str());
			ImGui::PopFont();

			ImGui::PopStyleVar(1);
			ImGui::PopStyleColor(4);
			ImGui::SetCursorPosY(MouseCursorPos.y);
			SpaceY(50);
		}

		
		ImGui::EndChild();

		ImGui::SameLine();
		



	constexpr ImVec2 RightChildSize = ImVec2(400, 425);

	ImGui::SetCursorPos(ImVec2(LeftChildSize.x, 0));
	ImVec4 ChildbgColor = ImGui::GetStyleColorVec4(ImGuiCol_ChildBg);
	ImGui::PushStyleColor(ImGuiCol_ChildBg , ImGui::GetStyleColorVec4(ImGuiCol_WindowBg));
	ImGui::BeginChild("Body", RightChildSize, false, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
	for (auto Child : s_MainMenu.at(s_RunningTab)->m_Childs)
	{

		ImGui::PushStyleVar(ImGuiStyleVar_ChildRounding, 5);
		ImGui::PushStyleColor(ImGuiCol_ChildBg, ImGui::GetStyleColorVec4(ImGuiCol_WindowBg));

		ImGui::SetCursorPos(ImVec2(0, 0));
		if (Child->mc_Size.x > RightChildSize.x)
		{
			Child->mc_Size.x = RightChildSize.x;
			Child->mc_Size.y = RightChildSize.y;
		}
		Child->mc_CursorPos = ImGui::GetCursorPos();
		ImVec4 ChildColor = ImGui::GetStyleColorVec4(ImGuiCol_ChildBg);
		ImDrawList* child_draw_list = nullptr;
		ImGui::BeginChild(Child->mc_Name.c_str(), Child->mc_Size, false, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
		{
			ImGui::PushStyleColor(ImGuiCol_Button, ImGui::GetStyleColorVec4(ImGuiCol_ChildBg));
			ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImGui::GetStyleColorVec4(ImGuiCol_ChildBg));
			ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImGui::GetStyleColorVec4(ImGuiCol_ChildBg));
			ImGui::PushStyleColor(ImGuiCol_Header, ImGui::GetStyleColorVec4(ImGuiCol_ChildBg));
			ImGui::PushStyleColor(ImGuiCol_HeaderHovered, ImGui::GetStyleColorVec4(ImGuiCol_ChildBg));
			ImGui::PushStyleColor(ImGuiCol_HeaderActive, ImGui::GetStyleColorVec4(ImGuiCol_ChildBg));
			ImGui::PushFont(LargeFont);

			if (Child->mc_EFunction)
				Child->mc_EFunction->Run();

			ImGui::PopFont();
			ImGui::PopStyleColor(6);
		}
		ImGui::EndChild();
		/*
		if (child_draw_list)
		{
			ImDrawList* draw_list = ImGui::GetWindowDrawList();
			ImVec2 window_pos = ImGui::GetWindowPos();
			ImColor TopColor = { 0,0,0,255 };
			ImColor DownColor = ImGui::GetStyleColorVec4(ImGuiCol_WindowBg);
			draw_list->AddRectFilledMultiColor(ImVec2(Child->mc_CursorPos.x + window_pos.x + 5, Child->mc_CursorPos.y + window_pos.y + Child->mc_Size.y - ImGui::GetScrollY()),
				ImVec2(Child->mc_CursorPos.x + window_pos.x + Child->mc_Size.x - 5, Child->mc_CursorPos.y + window_pos.y + Child->mc_Size.y + 10 - ImGui::GetScrollY()),
				TopColor, TopColor,
				DownColor, DownColor
			);
		}*/
		
		ImGui::PopStyleColor(1);
		ImGui::PopStyleVar(1);
		SpaceY(30);
	}
	ImGui::EndChild();
	ImGui::PopStyleColor(1);
}

MainMenu::Child::Child(MainMenu* Parent,const char* name, const ImVec2& size)
:mc_Name(name),mc_Size(size), _Parent(Parent)
{
	mc_Id = _Parent->m_MaxChildId++;
}
void MainMenu::CreateChild(const char* name, const ImVec2& size)
{
	m_ScopedChild = new Child(this, name, ImVec2(570,size.y));
	m_Childs.push_back(m_ScopedChild);
}
MainMenu::Child::~Child()
{
	delete this;
}
