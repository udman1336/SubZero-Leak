#ifndef CHEATS_H
#define CHEATS_H
#include "Headers.h"


//class MainMenu;

class EFunctions
{
public:
	void virtual Run() = 0;
};
class Aimbot : public EFunctions
{
public:
	void Run() override;
	void* _parent;
};
class Esp : public EFunctions
{
public:
	struct Element
	{
		bool _isEnabled{ false };
		float _color[4] = {0.8,0.2,0.8,1.f};
		inline ImVec4 GetColor()
		{
			return ImVec4(_color[0], _color[1], _color[2], _color[3]);
		}
		inline void SetColor(float x,float y, float z, float w = 1.)
		{
			_color[0] = x;
			_color[1] = y;
			_color[2] = z;
			_color[3] = w;
		}
		void Render(const char* name,int xSpaceing);
		
	};
	void ShowEspWindow();
	void Init();
	void Run() override;
	void* _parent;
	int _tab = 0;
	bool _isEnabled{ false };
	int _boxType = 0;
	Element _elementPlayerBox;
	Element _elementFillBox;
	Element _elementChamsSkin;
	Element _elementShowName;
	Element _elementHealth;
	Element _elementWeapon;
	Element _elementDistance;
	Element _elementIgnoreSleepers;
	Element _elementSkeleton;
	Element _elementBotsBoxes;
	Element _elementBotsSkeleton;




};


class Chat : public EFunctions
{
public:
	void Run() override;
	void* _parent;

};
extern Aimbot* g_pAimbot;
extern Esp* g_pEsp;
extern Chat* g_pChat;
#endif