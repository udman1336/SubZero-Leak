// Standard C++ and C libraries
#include <iostream> // Input/output stream library
#include <stdio.h> // C standard input/output library
#include <Windows.h> // Windows API library
#include <fstream> // File stream library
#include "xor.hpp" // Custom header file "xor.hpp"
#include <random> // Random number generation library

#pragma once // Preprocessor directive: Ensures the header file is included only once

// Standard C++ libraries
#include <iostream> // Input/output stream library
#include <sstream> // String stream library
#include <ctime> // Date and time library
#include <iomanip> // Input/output manipulation library
#include <algorithm> // Algorithm library
#include <vector> // Vector container library
#include <unordered_map> // Unordered map container library

// Windows-specific libraries
#include <Windows.h> // Windows API library
#include <iphlpapi.h> // IP Helper API library
#include <tchar.h> // Unicode character handling library
#include <netcon.h> // Network connection library
#undef max // Undefine 'max' macro to avoid conflicts

#pragma comment(lib, "IPHLPAPI.lib") // Link the IP Helper API library during compilation

int type = 0; // Declaration and initialization of an integer variable named "type" with the value 0
DWORD BytesReturned = 0; // Declaration and initialization of a Windows-specific data type 'DWORD' variable named "BytesReturned" with the value 0
std::string desired_serial; // Declaration of an empty C++ string named "desired_serial"
struct CustomRequest_Struct { // Definition of a C++ struct named "CustomRequest_Struct"
	const char* customserial; // Member of the struct, a pointer to a constant character (C-style string)
};

// Custom control codes for device I/O operations
#define RANDOMIZE CTL_CODE(FILE_DEVICE_UNKNOWN, 0x0420, METHOD_BUFFERED, FILE_SPECIAL_ACCESS) // Custom control code "RANDOMIZE" (device I/O control)
#define NULLING CTL_CODE(FILE_DEVICE_UNKNOWN, 0x0079, METHOD_BUFFERED, FILE_SPECIAL_ACCESS) // Custom control code "NULLING" (device I/O control)
#define CUSTOM CTL_CODE(FILE_DEVICE_UNKNOWN, 0x0323, METHOD_BUFFERED, FILE_SPECIAL_ACCESS) // Custom control code "CUSTOM" (device I/O control)
#define INITIALIZE CTL_CODE(FILE_DEVICE_UNKNOWN, 0x0072, METHOD_BUFFERED, FILE_SPECIAL_ACCESS) // Custom control code "INITIALIZE" (device I/O control)
