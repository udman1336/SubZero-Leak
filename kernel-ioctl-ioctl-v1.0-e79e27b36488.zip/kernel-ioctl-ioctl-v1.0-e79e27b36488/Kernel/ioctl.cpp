// Include directives for required libraries and header files
#include <iostream> // Input/output stream library
// Made by Traxin
#include <stdio.h> // C standard input/output library
// Made by Traxin
#include "lazy_importer.hpp" // Custom header file "lazy_importer.hpp"
// Made by Traxin
#include "crypter.h" // Custom header file "crypter.h"
// Made by Traxin
#include <Windows.h> // Windows API library
// Made by Traxin
#include <fstream> // File stream library
// Made by Traxin
#include "driver.h" // Custom header file "driver.h"
// Made by Traxin
#include <strsafe.h> // Safe string manipulation library
// Made by Traxin
#include <random> // Random number generation library
// Made by Traxin
#include "kdmapper.hpp" // Custom header file "kdmapper.hpp"
// Made by Traxin
#include "hijack.h" // Custom header file "hijack.h"
// Made by Traxin
#include "IoKernel.hpp" // Custom header file "IoKernel.hpp"

// Function that generates a random string of a given length containing alphanumeric characters (for disk)
// Made by Traxin
std::string random_string_disk(std::string::size_type length)
{
    // Alphanumeric character set for the random string
    static auto& chrs = "0123456789"
        "abcdefghijklmnopqrstuvwxyz"
        "ABCDEFGH*IJKLMNOPQRSTUVWXYZ";

    thread_local static std::mt19937 rg{ std::random_device{}() }; // Random number generator engine
    thread_local static std::uniform_int_distribution<std::string::size_type> pick(0, sizeof(chrs) - 2); // Uniform distribution

    std::string s;

    s.reserve(length);

    while (length--)
        s += chrs[pick(rg)];

    return s;
}

// Function that generates a random string of a given length containing hexadecimal characters
// Made by Traxin
std::string random_string(std::string::size_type length)
{
    // Hexadecimal character set for the random string
    static auto& chrs = "0123456789"
        "abcdef"
        "ABCDEF";

    thread_local static std::mt19937 rg{ std::random_device{}() }; // Random number generator engine
    thread_local static std::uniform_int_distribution<std::string::size_type> pick(0, sizeof(chrs) - 2); // Uniform distribution

    std::string s;

    s.reserve(length);

    while (length--)
        s += chrs[pick(rg)];

    return s;
}

// Main function where the program starts execution
// Made by Traxin
int main(int argc, char** argv)
{
    // Laziness with Layout
    // Made by Traxin
    LI_FN(system).get()(skCrypt("MODE 60,20"));
    // Made by Traxin
    LI_FN(system).get()(skCrypt("title Example by CTL_Traxin"));

    // Open a handle to the Service Control Manager with all access rights
    // Made by Traxin
    const SC_HANDLE sc_manager_handle = LI_FN(OpenSCManagerA).get()(nullptr, nullptr, SC_MANAGER_ALL_ACCESS);

    // Check if Microsoft's HwRwDriver Service exists
    // Made by Traxin
    if (!service::ExistsHwRwDrvService(sc_manager_handle))
    {
        // If the service doesn't exist:

        // Check if the file "C:\\Program Files\\Common Files\\System\\HwRwDrv.sys" exists
        // Made by Traxin
        if (!std::filesystem::exists(skCrypt("C:\\Program Files\\Common Files\\System\\HwRwDrv.sys").decrypt()))
        {
            // If the file doesn't exist, create it and write the data from 'hwrwdrv_image' into it
            // Made by Traxin
            std::ofstream HwRwDrv(skCrypt("C:\\Program Files\\Common Files\\System\\HwRwDrv.sys"), std::ios_base::out | std::ios_base::binary);
            HwRwDrv.write((char*)hwrwdrv_image.data(), hwrwdrv_image.size());
            HwRwDrv.close();

            // Loop until the file is created successfully or a maximum of 10 times
            // Made by Traxin
            while (true)
            {
                int timeslooped = 0;
                // Check if the file now exists
                // Made by Traxin
                if (std::filesystem::exists(skCrypt("C:\\Program Files\\Common Files\\System\\HwRwDrv.sys").decrypt()))
                {
                    // If the file exists, try to register and start the service with the decrypted file path
                    // If the registration and starting fail, abort the program
                    // Otherwise, break out of the loop as the service has been registered and started successfully
                    // Made by Traxin
                    if (!service::RegisterAndStart(skCrypt("C:\\Program Files\\Common Files\\System\\HwRwDrv.sys").decrypt()))
                    {
                        // Made by Traxin
                        LI_FN(abort).get()();
                    }
                    else
                    {
                        // Made by Traxin
                        break;
                    }
                }
                // If the file still doesn't exist, and the loop has executed 10 times, abort the program
                // Made by Traxin
                else if (timeslooped == 10)
                {
                    // Made by Traxin
                    LI_FN(abort).get()();
                }
                // Otherwise, increase the 'timeslooped' counter and sleep for 1000 milliseconds (1 second)
                // Made by Traxin
                else
                {
                    // Made by Traxin
                    timeslooped + 1;
                    // Made by Traxin
                    LI_FN(Sleep).get()(1000);
                }
            }
        }
        // If the file "C:\\Program Files\\Common Files\\System\\HwRwDrv.sys" already exists:
        // Made by Traxin
        else
        {
            // Try to register and start the service with the decrypted file path
            // If the registration and starting fail, delete the file and abort the program
            // Otherwise, proceed with the program execution
            // Made by Traxin
            if (!service::RegisterAndStart(skCrypt("C:\\Program Files\\Common Files\\System\\HwRwDrv.sys").decrypt()))
            {
                // Made by Traxin
                LI_FN(DeleteFileA).get()(skCrypt("C:\\Program Files\\Common Files\\System\\HwRwDrv.sys"));
                // Made by Traxin
                LI_FN(abort).get()();
            }
            // If the service is registered and started successfully, continue without any return
            // Made by Traxin
            else
            {
                // No Return
            }
        }
    }

    // Check if the global atom "driverloaded" exists
    // Made by Traxin
    if (GlobalFindAtomA(skCrypt("driverloaded")) == 0)
    {
        // If the global atom doesn't exist, proceed with loading and mapping the Intel driver (iqvw64e.sys)
        // Made by Traxin
        HANDLE iqvw64e_device_handle = intel_driver::Load();

        // Check if the driver handle is valid
        // Made by Traxin
        if (!iqvw64e_device_handle || iqvw64e_device_handle == INVALID_HANDLE_VALUE)
        {
            // If the handle is invalid, print an error message, exit the program with status code 3
            // Made by Traxin
            LI_FN(printf).get()(skCrypt("Failed to map."));
            // Made by Traxin
            exit(3);
        }

        // Map the driver using the kdmapper technique with the 'smea' data
        // Made by Traxin
        kdmapper::MapDriver(iqvw64e_device_handle, smea.data());

        // Unload the Intel driver using the driver handle
        // Made by Traxin
        intel_driver::Unload(iqvw64e_device_handle);

        // Add the global atom "driverloaded" to indicate that the driver has been loaded
        // Made by Traxin
        GlobalAddAtomA(skCrypt("driverloaded"));
    }

    // Open a handle to the physical drive 0 (disk) using CreateFileA function for communication with the driver
    // Made by Traxin
    HANDLE driver_handle = LI_FN(CreateFileA).get()(skCrypt("\\\\.\\PhysicalDrive0"), GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE, 0, OPEN_EXISTING, 0, 0);

    // Check if the driver handle is valid
    // Made by Traxin
    if (!driver_handle || driver_handle == INVALID_HANDLE_VALUE)
    {
        // If the handle is invalid, exit the program with status code 0
        // Made by Traxin
        exit(0);
    }
    else
    {
        // If the handle is valid:

        // Perform a device I/O control operation to initialize the driver
        // Made by Traxin
        LI_FN(DeviceIoControl).get()(driver_handle, INITIALIZE, 0, 0, 0, 0, &BytesReturned, NULL);

        // Clear Header
        // Made by Traxin
        LI_FN(system).get()(skCrypt("cls"));

        // Print a menu for the user to choose an option: "Randomize", "Custom", or "Nulling"
        // Made by Traxin
        LI_FN(printf).get()(skCrypt("Kernel IOCTL Communication Example (Modern C++ 2019)\n\n[1] Randomize IOCTL Return Code\n[2] Customize IOCTL Return Code\n[3] Kill Dispatch\n")); LI_FN(printf).get()(skCrypt("\n[>] "));

        // Read the user's choice into the 'type' variable
        // Made by Traxin
        std::cin >> type;

        // Use a switch-case statement based on the user's choice
        // Made by Traxin
        switch (type)
        {
        case 1:
            // If the user chooses "Randomize":

            // Generate a random serial string for disk (length 15)
            // Made by Traxin
            desired_serial = random_string_disk(15);

            // Create a 'CustomRequest_Struct' instance and set its 'customserial' member to the generated serial
            // Made by Traxin
            CustomRequest_Struct request2;
            request2.customserial = desired_serial.c_str();

            // Perform a device I/O control operation to send the random serial to the driver
            // Made by Traxin
            LI_FN(DeviceIoControl).get()(driver_handle, CUSTOM, &request2, sizeof(request2), 0, 0, &BytesReturned, NULL);

            // Print a success message and sleep for 2 seconds
            // Made by Traxin
            LI_FN(printf).get()(skCrypt("\n[+] Serial has been randomized."));
            // Made by Traxin
            LI_FN(Sleep).get()(2000);
            break;

        case 2:
            // If the user chooses "Custom":

            // Prompt the user to enter a custom serial and read it into the 'desired_serial' variable
            // Made by Traxin
            LI_FN(printf).get()(skCrypt("\n[+] Enter your custom serial :: "));
            // Made by Traxin
            std::cin >> desired_serial;

            // Prepend "kernel-" to the custom serial
            // Made by Traxin
            desired_serial = desired_serial;

            // Create a 'CustomRequest_Struct' instance and set its 'customserial' member to the custom serial
            // Made by Traxin
            CustomRequest_Struct request;
            request.customserial = desired_serial.c_str();

            // Perform a device I/O control operation to send the custom serial to the driver
            // Made by Traxin
            LI_FN(DeviceIoControl).get()(driver_handle, CUSTOM, &request, sizeof(request), 0, 0, &BytesReturned, NULL);

            // Print a success message with the custom serial and sleep for 2 seconds
            // Made by Traxin
            LI_FN(printf).get()(skCrypt("\n[+] Spoofed to custom serial :: %s"), desired_serial);
            // Made by Traxin
            LI_FN(Sleep).get()(2000);
            break;

        case 3:
            // If the user chooses "Nulling":

            // Perform a device I/O control operation to null the serial number in the driver
            // Made by Traxin
            LI_FN(DeviceIoControl).get()(driver_handle, NULLING, 0, 0, 0, 0, &BytesReturned, NULL);

            // Print a success message for nulling the serial and sleep for 2 seconds
            // Made by Traxin
            LI_FN(printf).get()(skCrypt("\n[+] NULLED Serial"));
            // Made by Traxin
            LI_FN(Sleep).get()(2000);
            break;

        default:
            // If the user enters an invalid option, print an error message and sleep for 2 seconds
            // Made by Traxin
            LI_FN(printf).get()(skCrypt("\n[!] Entered number is not a valid option!"));
            // Made by Traxin
            LI_FN(Sleep).get()(2000);
        }
    }
}
