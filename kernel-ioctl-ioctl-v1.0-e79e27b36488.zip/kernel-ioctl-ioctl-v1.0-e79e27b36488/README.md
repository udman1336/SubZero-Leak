**Native Kernel Driver - IOCTL Communication (Unsigned)**

This repo is an overall source storage for latest updates, or changes to the IOCTL driver provided by Traxin.

*I do recommend not trying to paste my driver as it will just BSOD without the proper CTL command structure which was alternated.*

---

## Work Notes

- Nothing to add as this was just uploaded recently

